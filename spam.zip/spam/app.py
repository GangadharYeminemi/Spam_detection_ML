from flask import Flask, request, jsonify, send_from_directory
import joblib
import re
import os

# Initialize Flask app
app = Flask(__name__, static_folder='.')

# Hardcoded stopword list
STOPWORDS = {
    'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from', 'has', 'he',
    'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the', 'to', 'was', 'were', 'will',
    'with', 'you', 'your', 'this', 'have', 'i', 'me', 'my', 'we', 'our', 'they', 'their'
}

# Load model and vectorizer
try:
    model = joblib.load('model.pkl')
    vectorizer = joblib.load('vectorizer.pkl')
except FileNotFoundError:
    print("Error: Model or vectorizer file not found. Please run train.py first.")
    exit(1)

# Function to preprocess text
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    tokens = text.split()
    tokens = [token for token in tokens if token not in STOPWORDS]
    return ' '.join(tokens)

# Serve index.html
@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

# Serve static files (e.g., styles.css)
@app.route('/<path:path>')
def serve_static(path):
    if os.path.exists(path):
        return send_from_directory('.', path)
    return "File not found", 404

# Prediction endpoint
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        # Preprocess and predict
        processed_message = preprocess_text(message)
        message_tfidf = vectorizer.transform([processed_message])
        prediction = model.predict(message_tfidf)[0]
        result = 'Spam' if prediction == 1 else 'Ham'
        
        return jsonify({'prediction': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=3000, debug=True)